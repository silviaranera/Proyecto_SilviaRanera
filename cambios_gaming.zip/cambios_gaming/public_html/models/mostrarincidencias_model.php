<?php

    //Muestra las incidencias
	function mostrar($conexion){
		try {
			$conexion=conexion();
			$consulta = $conexion->prepare("SELECT id_incidencia, descripcion, num_puesto, fecha 
											FROM incidencias
											ORDER BY fecha DESC ");	 
			$consulta->execute();	
			return $consulta;
		}catch(PDOException $e){
			echo $e->getMessage();
		}
		$conexion=null;
	}
	
?>