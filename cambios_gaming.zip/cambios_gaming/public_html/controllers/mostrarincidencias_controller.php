<?php

    session_start();
	if(isset($_SESSION['email'])){
		unset($_SESSION['email']);
		session_destroy();
		header("Location:../index.php");
	}

	include_once "../db/db.php";
	$conexion=conexion();
	
	include_once '../models/mostrarincidencias_model.php';
	
	if($_SERVER["REQUEST_METHOD"] == "POST") {	
	
		$datos=mostrar($conexion);
			
		var_dump ($datos);
		echo "<br> <br> <table border='2' width='60%' align='center' style='margin: 0px auto;'>";
                echo"<tbody>
                  	<tr> 
				  		<th> ID </th> 
						<th> Descripcion </th> 
						<th> Puesto</th>
						<th> Fecha </th> 
						 
				  	</tr>";
                   foreach ($datos as $dato) {
                      echo   "<tr>
                                  <td>".$dato['id_incidencias']."</td>
                                  <td>".$dato['descripcion']."</td>
                                  <td>".$dato['num_puesto']."</td>
                                  <td>".$dato['fecha']."</td>
                                  
                              </tr>";
                  } //fin foreach 
                  echo "</tbody></table>";
                  echo "<br>";	
		
	}
	
	include_once '../views/mostrarincidencias.php';

?>