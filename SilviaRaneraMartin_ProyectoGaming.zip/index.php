<?php
	require_once ("db/db.php");
	$conn=conexion();
	
	require_once ("views/web.php");
?>