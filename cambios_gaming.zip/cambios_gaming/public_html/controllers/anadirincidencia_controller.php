<?php
    session_start();
    
	if(isset($_SESSION['email'])){
		unset($_SESSION['email']);
		session_destroy();
		header("Location:../index.php");
	}
	
	require_once("../db/db.php");
    
	$conexion=conexion();
	
    require_once "../models/anadirincidencia_model.php";
			

	if($_SERVER["REQUEST_METHOD"] == "POST") {
        
		$fecha=$_POST["fecha"];
		$descripcion=$_POST["descripcion"];
        $puestos = $_POST["id"];
        $id_incidencia = obtenerid($conexion);
		//var_dump($_POST);
		
		if(isset($_POST["enviar"])){
            if($_POST["descripcion"] !="" && $_POST["fecha"] !="")
            {      
                alta($conexion,$id_incidencia,$descripcion,$puestos,$fecha);
				echo '<p style="color:green;font-size:20px;"> Se ha dado de alta correctamente </p>'."<br>";
				 echo "<script>alert('Las incidencias se han mandado correctamente');</script>";
			}else{
                echo "<script>alert('Faltan campos por rellenar');</script>";
            }
        }
	}
	
	require_once "../views/anadirincidencia.php";
	    
?>