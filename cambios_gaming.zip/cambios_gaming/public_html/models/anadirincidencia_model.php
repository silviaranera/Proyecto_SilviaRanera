<?php

//Obtiene el código que le corresponde a una nueva incidencia
function obtenerid($conexion){
	try {

		$consulta = $conexion->prepare("SELECT max(id_incidencia) as maximo FROM incidencias");
		$consulta->execute();

		$datos = $consulta->fetch(PDO::FETCH_ASSOC);

		return $datos["maximo"]+1;

	} catch (PDOException $ex) {
		return null;
	}
}

//Muestra los id puestos de ordenadores
function mostrarpuestos($conexion){
    try {
        $conexion=conexion();
        $consulta = $conexion->prepare("SELECT num_puesto FROM ordenador ORDER BY num_puesto ASC");	 
        $consulta->execute();	
        echo "<select name='id' required>";
            foreach($consulta->fetchAll() as $consulta){
                echo '<option value="'.$consulta["num_puesto"].'"> Puesto: 
                '.$consulta["num_puesto"].'</option>';
            }
        echo "</select>";
        
    }catch(PDOException $e){
        echo $e->getMessage();
    }
    $conexion=null;
}


//Da de alta la incidencia descrita
function alta($conexion,$id_incidencia,$descripcion,$puestos,$fecha){
	try{  
        $insert = $conexion->prepare("INSERT INTO `incidencias`(`id_incidencia`, `descripcion`, `num_puesto`, `fecha`)                           VALUES ('$id_incidencia', '$descripcion', '$puestos', '$fecha')");
        $insert->execute();

    }catch(PDOException $e){
        echo $e->getMessage();
	}
}

?>