<?php
    session_start();
    
	require_once("../db/db.php");
    
	$conexion=conexion();
	
    require_once "../models/disponibilidadjuego_model.php";
			

	if($_SERVER["REQUEST_METHOD"] == "POST") {
		
	
		$disponibilidad=$_POST["disponibilidad"];

		$idjuego = $_POST["ids"];
			//var_dump($_POST);
		if(isset($_POST["enviar"])){
		    if($_POST["disponibilidad"] !="")
		    {      
			cambiosjuego($conexion,$idjuego,$disponibilidad);
				echo '<p style="color:green;font-size:20px;"> Se ha modificado correctamente </p>'."<br>";	
			}else{
				echo "<script>alert('Faltan campos por rellenar');</script>";
			}
		}elseif(isset($_POST["volver"])) {
			header ("location:../views/menuadmin.php");
		}
	}
	
	require_once "../views/disponibilidadjuego.php";
	    
?>
